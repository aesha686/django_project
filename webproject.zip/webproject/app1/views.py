from django.shortcuts import render

def navbar(req):
    return render(req, "navbar.html")

def handle_form(req):
    if req.method == "POST":
        name = req.POST.get('name')
        email = req.POST.get('email')
        password = req.POST.get('password')
        hobbies = req.POST.getlist('hobbies')
        gender = req.POST.get('gender')
        context = {
            'name': name,
            'email': email,
            'password': password,
            'hobbies': hobbies,
            'gender': gender,
        }
        return render(req, 'display.html', context)
    return render(req, 'navbar.html')
